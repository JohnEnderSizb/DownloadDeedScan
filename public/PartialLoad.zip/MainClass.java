import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;
import java.util.*;
import java.io.File;

public class MainClass {
	public static void main(String[] args) {
		ExecutorService executorService = Executors.newFixedThreadPool(3);

		File balancesFile = new File(args[0]);//commandline aruoment 1
		boolean exists = balancesFile .exists();
		if (exists) {
			AccountBalancesTXTFile  myFile = new AccountBalancesTXTFile("testfile.txt", "./");
			Map map;
			while(myFile.hasNextLine()) {
				map = myFile.readFile();
				System.out.println(map.get("accountName"));

				String accountName = map.get("accountName").toString();
	    		String ledgerBalance = map.get("ledgerBalance").toString();
	    		String availableBalance = map.get("availableBalance").toString();

	    		Account account = new Account(accountName, ledgerBalance, availableBalance);

	    		UpdateRequest updateRequest = new UpdateRequest(args[1], account);

	    		Runnable task = () -> {
	            System.out.println("Executing Task inside : " + Thread.currentThread().getName());
	            	updateRequest.makeGetRequest();
		    		String requestStatus = updateRequest.getRequestStatus();
		    		System.out.println(requestStatus);
	        	};

	        	executorService.submit(task);

			}//while
			myFile.cleanUp();
			executorService.shutdown();
		}

	}
}